# Telos Monitor 🔍

Reddit에서 키워드 모니터링 → 이메일 알림 + AI 답변 초안 자동 생성

## 동작 방식
- GitHub Actions가 **매 1시간마다** 자동 실행
- Reddit RSS에서 키워드 검색
- 새 게시물 발견 시 이메일로 알림
- Claude AI가 답변 초안 자동 생성

## 설정 방법

### 1. GitHub Secrets 설정
GitHub 레포 → Settings → Secrets → New repository secret

| Secret 이름 | 값 |
|------------|-----|
| `GMAIL_USER` | telos.doctor@gmail.com |
| `GMAIL_PASS` | Gmail 앱 비밀번호 |
| `NOTIFY_EMAIL` | 알림 받을 이메일 |
| `ANTHROPIC_API_KEY` | Claude API 키 |

### 2. Gmail 앱 비밀번호 만들기
1. Google 계정 → 보안
2. 2단계 인증 켜기
3. 앱 비밀번호 생성 → "메일" 선택
4. 생성된 16자리 비밀번호 복사

## 모니터링 키워드
`monitor.py`의 `KEYWORDS` 리스트에서 수정 가능

## 모니터링 서브레딧
`monitor.py`의 `SUBREDDITS` 리스트에서 수정 가능
