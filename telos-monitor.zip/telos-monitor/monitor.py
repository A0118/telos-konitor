import feedparser
import requests
import json
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timezone, timedelta

# ── 키워드 설정 ──────────────────────────────────────────
KEYWORDS = [
    "Rejuran Seoul",
    "Rejuran Korea",
    "Korean skincare clinic",
    "GLP-1 Korea",
    "GLP-1 Seoul",
    "medical tourism Seoul",
    "Ulthera Seoul",
    "Exosome Seoul",
    "Korean aesthetic clinic",
    "Seoul dermatologist",
    "Mounjaro Korea",
    "Wegovy Korea",
    "PDRN Korea",
]

# ── 모니터링 서브레딧 ────────────────────────────────────
SUBREDDITS = [
    "koreatravel",
    "Seoul",
    "skincareaddiction",
    "AsianBeauty",
    "PlasticSurgery",
    "Semaglutide",
    "Ozempic",
    "WegovyWeightLoss",
    "MedicalTourism",
    "koreanskincare",
    "KoreanBeauty",
]

# ── YouTube 채널/키워드 ──────────────────────────────────
YOUTUBE_SEARCH_TERMS = [
    "Rejuran Seoul clinic",
    "Korean skincare treatment",
    "GLP-1 Korea price",
    "Seoul medical tourism",
]

def check_reddit_rss():
    """Reddit RSS 피드에서 키워드 검색"""
    found = []
    cutoff = datetime.now(timezone.utc) - timedelta(hours=2)

    for subreddit in SUBREDDITS:
        for keyword in KEYWORDS:
            url = f"https://www.reddit.com/r/{subreddit}/search.rss?q={keyword.replace(' ', '+')}&sort=new&restrict_sr=1"
            try:
                feed = feedparser.parse(url)
                for entry in feed.entries:
                    # 최근 2시간 내 게시물만
                    published = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
                    if published > cutoff:
                        found.append({
                            'platform': 'Reddit',
                            'subreddit': f"r/{subreddit}",
                            'keyword': keyword,
                            'title': entry.title,
                            'link': entry.link,
                            'published': published.strftime('%Y-%m-%d %H:%M UTC'),
                            'summary': entry.summary[:300] if hasattr(entry, 'summary') else '',
                        })
            except Exception as e:
                print(f"Error fetching r/{subreddit} for '{keyword}': {e}")

    return found

def generate_reply_draft(item):
    """Claude API로 답변 초안 생성"""
    try:
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": os.environ.get("ANTHROPIC_API_KEY", ""),
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 300,
                "messages": [{
                    "role": "user",
                    "content": f"""You are a helpful medical concierge for Telos (telos.beauty), a Seoul-based medical concierge for English-speaking patients.

Someone posted on {item['platform']} ({item['subreddit']}):
Title: {item['title']}
Content: {item['summary']}

Write a SHORT, helpful, natural-sounding reply (2-3 sentences max). 
- Be genuinely helpful, not salesy
- Mention telos.beauty naturally only if very relevant
- Focus on answering their question
- Sound like a real person, not a bot"""
                }]
            }
        )
        data = response.json()
        return data['content'][0]['text']
    except:
        return "답변 초안 생성 실패 - 수동으로 작성해주세요."

def send_email_notification(found_items):
    """이메일로 알림 전송"""
    gmail_user = os.environ.get('GMAIL_USER')
    gmail_pass = os.environ.get('GMAIL_PASS')
    notify_email = os.environ.get('NOTIFY_EMAIL')

    if not all([gmail_user, gmail_pass, notify_email]):
        print("이메일 설정 없음 - 콘솔 출력만")
        return

    msg = MIMEMultipart('alternative')
    msg['Subject'] = f"🔔 Telos Monitor - {len(found_items)}개 새 게시물 발견"
    msg['From'] = gmail_user
    msg['To'] = notify_email

    html_content = f"""
<html><body style="font-family: Arial, sans-serif; max-width: 700px; margin: 0 auto;">
<div style="background: #0a1628; padding: 24px; border-radius: 8px 8px 0 0;">
  <h1 style="color: #c9a96e; margin: 0; font-size: 20px;">🔔 Telos Monitor</h1>
  <p style="color: #8899aa; margin: 8px 0 0;">{datetime.now().strftime('%Y-%m-%d %H:%M')} · {len(found_items)}개 게시물 발견</p>
</div>
"""

    for i, item in enumerate(found_items, 1):
        draft = generate_reply_draft(item)
        html_content += f"""
<div style="border: 1px solid #e0e0e0; border-radius: 8px; margin: 16px 0; overflow: hidden;">
  <div style="background: #f8f8f8; padding: 12px 16px; border-bottom: 1px solid #e0e0e0;">
    <span style="background: #0a1628; color: #c9a96e; padding: 3px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">{item['platform']}</span>
    <span style="color: #888; font-size: 13px; margin-left: 8px;">{item['subreddit']} · {item['published']}</span>
  </div>
  <div style="padding: 16px;">
    <h3 style="margin: 0 0 8px; font-size: 16px;">
      <a href="{item['link']}" style="color: #0a1628; text-decoration: none;">{item['title']}</a>
    </h3>
    <p style="color: #667788; font-size: 14px; margin: 0 0 12px; line-height: 1.6;">{item['summary'][:200]}...</p>
    <div style="background: #f0f8f0; border-left: 3px solid #4CAF50; padding: 12px; border-radius: 0 8px 8px 0;">
      <p style="font-size: 12px; color: #888; margin: 0 0 6px; font-weight: bold;">💬 AI 답변 초안</p>
      <p style="font-size: 14px; color: #334; margin: 0; line-height: 1.6;">{draft}</p>
    </div>
    <a href="{item['link']}" style="display: inline-block; margin-top: 12px; background: #0a1628; color: #c9a96e; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-size: 13px; font-weight: bold;">게시물 보기 →</a>
  </div>
</div>
"""

    html_content += """
<div style="background: #f8f8f8; padding: 16px; border-radius: 0 0 8px 8px; text-align: center;">
  <p style="color: #aaa; font-size: 12px; margin: 0;">Telos Monitor · telos.beauty · 매 1시간마다 자동 실행</p>
</div>
</body></html>
"""

    msg.attach(MIMEText(html_content, 'html'))

    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login(gmail_user, gmail_pass)
        server.sendmail(gmail_user, notify_email, msg.as_string())
        server.quit()
        print(f"✅ 이메일 전송 완료: {notify_email}")
    except Exception as e:
        print(f"❌ 이메일 전송 실패: {e}")

def main():
    print(f"🔍 Telos Monitor 시작 - {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"모니터링 키워드: {len(KEYWORDS)}개")
    print(f"모니터링 서브레딧: {len(SUBREDDITS)}개")

    # Reddit 모니터링
    print("\n📡 Reddit RSS 스캔 중...")
    reddit_found = check_reddit_rss()
    print(f"Reddit: {len(reddit_found)}개 발견")

    all_found = reddit_found

    if all_found:
        print(f"\n🎯 총 {len(all_found)}개 게시물 발견!")
        for item in all_found:
            print(f"  - [{item['platform']}] {item['title'][:60]}...")
        send_email_notification(all_found)
    else:
        print("\n✅ 새 게시물 없음")

if __name__ == "__main__":
    main()
